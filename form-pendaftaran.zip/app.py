from flask import Flask, render_template, request
import pandas as pd
import os

app = Flask(__name__)
DATA_FILE = 'data_pendaftaran.csv'

@app.route('/')
def form():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit():
    nama = request.form['nama']
    nis = request.form['nis']
    alamat = request.form['alamat']
    provinsi = request.form['provinsi']
    kabupaten = request.form['kabupaten']
    kecamatan = request.form['kecamatan']

    data = {
        'Nama': [nama],
        'NIS': [nis],
        'Alamat': [alamat],
        'Provinsi': [provinsi],
        'Kabupaten': [kabupaten],
        'Kecamatan': [kecamatan]
    }

    df = pd.DataFrame(data)

    if os.path.exists(DATA_FILE):
        df.to_csv(DATA_FILE, mode='a', header=False, index=False)
    else:
        df.to_csv(DATA_FILE, index=False)

    return "Pendaftaran berhasil! Data kamu telah kami simpan."

if __name__ == '__main__':
    import os
    port = int(os.environ.get("PORT", 5000))
    app.run(host='0.0.0.0', port=port)
